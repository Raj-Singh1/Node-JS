var EventEmitter = require("events").EventEmitter;
var ee = new EventEmitter();

// ee.once("ok",function(){
//     console.log("ok raised");
// });

// ee.emit("ok");
// ee.emit("ok");

// ee.on("ok",function(){
//     console.log("ok raised");
// });

// ee.emit("ok");
// ee.emit("ok");

var timer;

ee.on("start",(startPos)=>{
    var i = startPos;
    console.log("starting timer");
    timer = setInterval(()=>{
        console.log(i);
        i++;
    },500);
});

ee.on("stop",()=>{
    console.log("stopped timer");
    clearInterval(timer);
});

ee.emit("start",100);

setTimeout(()=>{
    ee.emit("stop");
  //  ee.emit("start",50);
},10000);

