function sh(name,callback){

    setTimeout(()=>{
        callback("hello "+name);
    },1000)
}

sh("sagar",function(res){
    console.log(res);
});

console.log("completed");