var buff = Buffer.from("sample data");
console.log(buff.toString());

var buff1 = Buffer.alloc(1000);
// buff1.write("This is sample data");
// console.log(buff1.toString());
var noofBytesWritten = buff1.write("This is sample data");
console.log("Bytes Written : "+noofBytesWritten);
console.log(buff1.toString());