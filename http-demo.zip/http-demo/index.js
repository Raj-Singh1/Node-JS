var http = require("http");
var { requesthandler } = require("./requesthandler");

var server = http.createServer(requesthandler);


server.listen(7000, (err)=>{
    if(err){
        console.log("Could not start server");
        return;
    }
    console.log("Server started in port 7000");
});