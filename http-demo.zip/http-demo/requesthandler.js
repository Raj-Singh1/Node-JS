var fs = require("fs");
var path = require("path");

exports.requesthandler = (req, res) => {
    res.setHeader("Content-Type", "text/html");
    var layout = getViewContent("layout.html");
    if (req.url == "/") {
        var body = getViewContent("index.html");
        var content = layout.replace("{{body-content}}", body);
        res.write(content);
        res.end();
    }
    else if (req.url == "/about") {
        var body = getViewContent("about.html");
        var content = layout.replace("{{body-content}}", body);
        res.write(content);
        res.end();
    }
    else if (req.url == "/contact") {
        var body = getViewContent("contact.html");
        var content = layout.replace("{{body-content}}", body);
        res.write(content);
        res.end();
    }
    else if (req.url == "/register" && req.method == "GET") {
        var body = getViewContent("register.html");
        var content = layout.replace("{{body-content}}", body);
        res.write(content);
        res.end();
    }
    else if (req.url == "/register" && req.method == "POST") {
        var formData = "";
        req.on("data", (chunk) => {
            formData += chunk;
        });
        req.on("end", () => {
            res.write(formData);
            res.end();
        })
    }
}

function getViewContent(filename) {
    var filePath = path.resolve(__dirname, "views", filename);
    var content = fs.readFileSync(filePath);
    return (content.toString());
}