function sayGoodmorning(name){
    return `Good Morning ${name}`;
}

function sayGoodafternoon(name){
    return `Good Afternoon ${name}`;
}

function sayGoodevening(name){
    return `Good Evening ${name}`;
}

module.exports={
    // sayGoodafternoon,
    getGoodAfternoon : sayGoodafternoon,
    sayGoodmorning,
    sayGoodevening
}