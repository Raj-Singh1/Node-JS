var Person = require("./person");
var Greeting = require("./greeting");
var Calculator = require("./calculator");
// var sayGaf = require("./greeting").sayGoodafternoon;
var sayGaf = require("./greeting").getGoodAfternoon;
var { sayGoodevening, getGoodAfternoon } = require("./greeting");

var a= 5, b=3;
var res=Calculator.mul(a,b);
console.log(`Product of multiply is ${res}`);

var res=Calculator.add(a,b);
console.log(`Product of add is ${res}`);

var res=Calculator.sub(a,b);
console.log(`Product of sub is ${res}`);

var res=Calculator.divide(a,b);
console.log(`Product of divide is ${res}`);

 var person = new Person();
person.firstname="Rishu";
person.lastname="Sharma";
var fullname = person.getFullname();
var greeting =sayGaf(fullname);
console.log(greeting);
// console.log(sayGaf);
// var greeting = Greeting.sayGoodevening(fullname);
// console.log(greeting);
var greeting = sayGoodevening(fullname);
console.log(greeting);
var greeting = getGoodAfternoon(fullname);
console.log(greeting);
var greeting = Greeting.sayGoodmorning(fullname);
console.log(greeting);