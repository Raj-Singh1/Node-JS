var fs = require("fs");
var path = require("path");


// var filePath = path.resolve(__dirname,'myfiles',"filename");
// console.log(filePath);
// var {writeContentSync, readContentSync} = require("./filehandler");
// var {writeFileContent, readFileContent} = require("./filehandler");
var { writeToFileStream, readToFileStream } = require("./filehandler");




// console.log(__dirname);
// console.log(__filename);

var data = "Hello how are you";
var filename = "myfileContent.txt";

// writeFileContent(filename, data);
// readFileContent(filename);

writeToFileStream(filename, data);
readToFileStream(filename);

// var filename="myfiles1.txt";

//  writeContent(filename, data);
//readContent(filename);
// readContent(filename,res=>{
//     console.log(res.toUpperCase());
// });


// writeContentSync(filename, data);
// readContentSync(filename);


// var filePath = path.resolve(__dirname, 'myfile', filename);
// fs.stat(filePath, (err, stats)=>{
//     console.log(stats)
// })

// fs.watchFile(filePath, (prev, current)=>{
//     console.log(prev.mtime+"----------------"+current.mtime);
//     console.log(prev.size+"------------"+current.size);
// })