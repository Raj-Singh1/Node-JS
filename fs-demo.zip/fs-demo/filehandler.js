var fs = require("fs");
var path = require("path");


exports.writeContent = (filename, content) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    fs.open(filePath, "w", (err, fd) => {
        if (err) {
            console.log("Failed to continue");
            return;
        }
        else {
            fs.write(fd, Buffer.from(content), (err, noOfBytes, buff) => {
                if (err) {
                    console.log("Failed to write");
                    return;
                }
                else {
                    console.log("Successfully written the content");
                    fs.close(fd, (err) => {
                        if (err) {
                            console.log("Failed to Close");
                            return;
                        }
                        else {
                            console.log("File closed after writing");
                        }
                    })
                }
            })
        }
    })
}

exports.readContent = (filename, callback) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    fs.open(filePath, "r", (err, fd) => {
        if (err) {
            console.log("Error in loading file");
            return;
        }
        var buffer = Buffer.alloc(20);
        fs.read(fd, buffer, 0, 20, 0, (err, Bytelength, buff) => {
            if (err) {
                console.log("Failed to read");
                return;
            }
            callback(buff.toString());
            //console.log(buff.toString());
            fs.close(fd, (err) => {
                if (err) {
                    console.log("error in closing the file after reading");
                    return;
                }
                console.log("File closed after reading");
            })
        })
    })
}

exports.writeContentSync = (filename, content) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    var fd = fs.openSync(filePath, "w");
    if (!fd) {
        return;
    }
    var bytes = fs.writeSync(fd, Buffer.from(content));
    console.log("File written successfully");
    fs.closeSync(fd);
}

exports.readContentSync = (filename) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    var fd = fs.openSync(filePath, "r");
    if (!fd) {
        return;
    }
    var buffer = Buffer.alloc(120);
    var bytes = fs.readSync(fd, buffer, 0, 120, 0);
    console.log(buffer.toString());
    fs.closeSync(fd);
}

exports.writeFileContent = (filename, content) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    fs.readFile(filePath, { encoding: "utf-8" }, (err, data) => {
        if (err) {
            console.log("Error in writing file content");
            return;
        }
        console.log("Successfully written in to file");
    })
}

exports.readFileContent = (filename) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    fs.readFile(filePath, { encoding: "utf-8" }, (err, data) => {
        if (err) {
            console.log("Error in reading file content");
            return;
        }
        console.log(data);
    })
}

exports.writeFileContentSync = (filename, content) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    fs.writeFile(filePath, { encoding: "utf-8" }, (err, data) => {
        if (err) {
            console.log("Error in writing file content");
            return;
        }
        console.log("Successfully written in to file");
    })
}


exports.readFileContentSync = (filename) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    fs.readFile(filePath, { encoding: "utf-8" }, (err, data) => {
        if (err) {
            console.log("Error in reading file content");
            return;
        }
        console.log(data);
    })
}

exports.writeToFileStream = (filename, content) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    var stream = fs.createWriteStream(filePath, { encoding: "utf-8" });
    stream.write(content);
    stream.close();
}

exports.readToFileStream = (filename) => {
    var filePath = path.resolve(__dirname, 'myfile', filename);
    var stream = fs.createReadStream(filePath, { encoding: "utf-8" });
    var content;
    stream.on("data", (chunk) => {
        content += chunk;
    });
    stream.on("end", () => {
        console.log("Streaming completed");
        console.log(content);
        stream.close();
    })
}