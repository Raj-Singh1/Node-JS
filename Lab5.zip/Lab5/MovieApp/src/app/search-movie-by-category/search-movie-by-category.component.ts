import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-movie-by-category',
  templateUrl: './search-movie-by-category.component.html',
  styleUrls: ['./search-movie-by-category.component.css']
})
export class SearchMovieByCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
