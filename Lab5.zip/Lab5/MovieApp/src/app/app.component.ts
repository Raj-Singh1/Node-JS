import { Component, OnInit } from '@angular/core';
import { ProductService } from './services/product.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';

  private products:any ;

  constructor(private prodSvc:ProductService){}

  ngOnInit(){

    // var p={
    //   name:"aa",
    //   price:25,
    //   quantity:45
    // }
    // this.prodSvc.addProduct(p)
    // .subscribe(
    //   res=>{
    //     console.log("success")
    //   },
    //   err=>{
    //     console.log(err );
    //   }
    // )

    this.prodSvc.getProducts()
    .subscribe(
      res=>{ 
        console.log(res); 
        this.products=res;
      },
      err=>{console.log(err)}
    )
  }
}
