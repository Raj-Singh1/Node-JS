import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { AddMoviesComponent } from './add-movies/add-movies.component';
import { SearchMovieByCategoryComponent } from './search-movie-by-category/search-movie-by-category.component';
import { ProductService } from './services/product.service';


@NgModule({
  declarations: [
    AppComponent,
    AddMoviesComponent,
    SearchMovieByCategoryComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [
    ProductService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
